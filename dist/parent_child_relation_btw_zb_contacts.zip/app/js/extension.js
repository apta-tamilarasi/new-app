window.onload = function () {
  console.log('trigger');
  ZFAPPS.extension.init().then(function (App) {
    console.log(App);

    var contacts = {
      url: 'https://www.zohoapis.com/books/v3/contacts?organization_id=830021604',
      method: "GET",
      body: {
        mode: 'raw',
        raw: 'RAWDATA'
      },
      connection_link_name: 'zohobookscontact'
    };
    console.log(contacts)


    ZFAPPS.request(contacts).then(function (value) {

      let parentselect = document.getElementById('parent-select')

      let responseJSON = JSON.parse(value.data.body);
      console.log(responseJSON);

      let contacts = responseJSON.contacts
      console.log(contacts);

      let parent_contact_details = contacts.map((e, i) => {
        console.log('parent-map');
        var parent_opt = document.createElement('option')
        parent_opt.textContent = e.contact_name
        parent_opt.value = e.contact_name
        parentselect.append(parent_opt)
      })

      var childselect = document.getElementById('child-select');
      function opt() {
        contacts.forEach(function (option) {
          var opt = document.createElement('option');
          opt.appendChild(document.createTextNode(option.contact_name));
          opt.value = option.contact_name;
          childselect.appendChild(opt);
        });
        M.FormSelect.init(childselect);
      }
      opt()

    }).catch(function (err) {
      console.log("request err", err);
    })
  })


}

let save_the_details = () => {
  var childselect = document.getElementById('child-select')
  let parentselect = document.getElementById('parent-select')

  var multiple=false

  var parentselectedvalues
  var childselectedvalues = []
  for (var i = 0; i < parentselect.options.length; i++) {
    var option = parentselect.options[i];
    if (option.selected) {
      parentselectedvalues = option.value
    }
  }
  for (var i = 0; i < childselect.options.length; i++) {
    var option = childselect.options[i];
    if (option.selected) {
      childselectedvalues.push(option.value)
      multiple=true
    }
  }
  console.log(parentselectedvalues);
  console.log(childselectedvalues);

  var parent_child_select= {
    cf__ungzm_parent_child:parentselectedvalues,
    cf__ungzm_child_select:childselectedvalues

  }
  console.log(parent_child_select);
 if(multiple){
  var options = {
    url: 'https://www.zohoapis.com/books/v3/cm__ungzm_custom_module?organization_id=830021604',
    method: "POST",
    body: {
      mode: 'raw',
      raw: parent_child_select
    },
    connection_link_name: 'zohobookscontact'
  };
  console.log(options);
  ZFAPPS.request(options).then(function (value) {
    let responseJSON = JSON.parse(value.data.body);
    console.log('success', responseJSON);
  }).catch(function (err) {
    console.log('err', err);
  });
 }
 else{
  alert("Please select the child company")
 }
}



